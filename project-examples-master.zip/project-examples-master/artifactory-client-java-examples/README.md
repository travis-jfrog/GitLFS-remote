# Artifactory Java Client Examples
## Overview
The Artifactory Java Client provides a set of java APIs which you use to work with JFrog Artifactory from your java code.
It Allows managing Artifactory repositories, users, groups, permissions and system configuration. It also allows searches, 
upload and download artifacts to or from Artifactory and a lot more.
The client's documentation is available [here](https://github.com/JFrog/artifactory-client-java).<br />
We created a few project examples, to help you get started using the client.