# How I Leaped Forward My Jenkins Build with JFrog Pipelines

This examples demonstrates different ways to accelerate and improve your CI/CD, with JFrog Pipelines as part of your SDLC.
The full description of how to set up and run this examples are available on <---this blog post--->.
