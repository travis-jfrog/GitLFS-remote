MSBuild Project Example
==========================

	
### Configuration
* On the Solution level you can find the ".artifactory\Artifactory.build" file, which is the main plugin configuration for
  all the projects under the solution.
* The project called "Artifactory" was created by the project template installation.
* Also for configuring deployment patterns that is unique to a specific project, you can put the configuration file under the 
  project, like in the `Artifactory.DAL` in our example.

Full Wiki documentation can be found in the following like: 
http://www.jfrog.com/confluence/display/RTF/MSBuild+Artifactory+Plugin


### Running
Build the Solution  
