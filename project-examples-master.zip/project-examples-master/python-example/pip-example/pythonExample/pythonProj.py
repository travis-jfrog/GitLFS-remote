#!/usr/bin/python

# Function definition is here
def printme( str ):
    # This prints a passed string into this function
    print (str)
    return;

# Now you can call printme function
printme("Hello from JFROG");
