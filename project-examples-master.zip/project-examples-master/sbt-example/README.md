#### SBT Example
This is a sample project that resolve a dependency from Artifactory and deploys the build artifacts to Artifactory.

#### Running this example
```console
> sbt clean compile package publish
```